# Prusa i3 Bear Half Upgrade

## Manual

### Table of Content

1. [Bill Of Material](bom.md)
1. [Print Settings](print_settings.md)
1. [V-Slots Instructions](vslots_instructions.md)
1. [Preflight Check And Disassembly](preflight_check_disassembly.md)
1. [Frame Drilling Instructions](frame_drilling_instructions.md)
1. [Assembly Instructions](assembly_instructions.md)