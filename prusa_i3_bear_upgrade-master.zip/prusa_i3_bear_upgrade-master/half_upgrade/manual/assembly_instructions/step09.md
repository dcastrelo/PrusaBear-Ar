# Prusa i3 Half Upgrade

## Assembly Instructions

### Step 9

#### Assembly

1. You can then mount the Y belt and Y pulleys
1. Unscrew a bit the y_idler to help you when adjusting belt tension
1. Check that belt is perfectly aligned in centre of Y idler pulley and Y motor GT2-16 pulley

/!\ Warning: these parts will not be visible on next assembly steps


#### [Previous Step](step08.md) &nbsp;&nbsp;&nbsp; [Next Step](step10.md)