# Prusa i3 Half Upgrade

## Assembly Instructions

* [Step 1](assembly_instructions/step01.md)
* [Step 2](assembly_instructions/step02.md)
* [Step 3](assembly_instructions/step03.md)
* [Step 4](assembly_instructions/step04.md)
* [Step 5](assembly_instructions/step05.md)
* [Step 6](assembly_instructions/step06.md)
* [Step 7](assembly_instructions/step07.md)
* [Step 8](assembly_instructions/step08.md)
* [Step 9](assembly_instructions/step09.md)
* [Step 10](assembly_instructions/step10.md)
* [Step 11](assembly_instructions/step11.md)
* [Step 12](assembly_instructions/step12.md)
* [Step 13](assembly_instructions/step13.md)
* [Step 14](assembly_instructions/step14.md)
* [Step 15](assembly_instructions/step15.md)
