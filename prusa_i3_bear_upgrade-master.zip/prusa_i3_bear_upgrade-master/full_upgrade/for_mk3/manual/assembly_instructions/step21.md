# Prusa i3 Full Upgrade MK3

## Assembly Instructions

### Step 21

#### Assembly

1. Run XYZ calibration
1. Calibrate Z level
1. Happy printing :relaxed:

#### [Previous Step](step20.md)
