# Prusa i3 Bear Full Upgrade MK3


## V-Slots Instructions

This instructions are useful if you did not purchase pre-cut Openbuilds V-Slots


### Cutting


#### Machine cut

The best way to cut V-Slots is to use a mitre saw with special aluminum blade and lubricant.

Another way is to use a circular saw but you will need a cross-cut sled. As well as for mitre saw, a special aluminum blade and lubricant are necessary.


#### Hand cut

You can hand cut them accurately using a jig (it just takes more time and effort). I have build one, all details are here : https://www.thingiverse.com/thing:2596242


### Dimensions

![Prusa i3 Bear Full Upgrade MK3 V-Slots Length](/full_upgrade/for_mk3/doc/vslots_length.png)