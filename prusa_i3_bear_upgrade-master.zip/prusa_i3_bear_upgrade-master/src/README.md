# Bear Upgrade

## Files

* copy_common_parts.sh -> script to copy common parts from MK2 to other versions
* bear_full_upgrade_mk2.f3z -> Fusion 360 project for full upgrade of MK2, MK2s and MK2.5 printer versions
* bear_full_upgrade_mk3.f3z -> Fusion 360 project for full upgrade of MK3 printer version
* bear_half_upgrade.f3z -> Fusion 360 project for half upgrade of MK2, MK2s and MK2.5 printer versions