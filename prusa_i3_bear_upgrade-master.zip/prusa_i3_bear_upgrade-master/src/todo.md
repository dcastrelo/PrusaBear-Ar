# Prusa i3 Bear Upgrade

## To Do List

1. Add Y support for the back of motor on MK2
1. Connect frame to earth ground
1. Add disassembly steps in manual
1. Explains to test printer calibration with z_top and smooth rod before disassembling the printer
1. ~~Fix Z motor mount issue : https://github.com/prusa3d/Original-Prusa-i3/issues/49~~
1. Fix Y motor mount issue : https://github.com/prusa3d/Original-Prusa-i3/issues/50
1. ~~Make motor mount 0.45mm deeper to perfectly cover the motor~~
1. Prusa logo on Full upgrade (as an option)