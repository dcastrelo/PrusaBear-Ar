# Prusa i3 Bear Upgrade

## Credits

Here are a list of sources I used to build this project :

* Prusa : http://www.prusa3d.com
* Prusa 3030 Haribo Edition : https://github.com/PrusaMK2Users/3030_Haribo_Edition
* Openbuilds : https://www.openbuilds.org
* Prusa i3 Solidworks parts from jzkmath : https://github.com/jzkmath/Original-Prusa-i3/

Huge thanks to these projects, without the Bear upgrade can not exist!