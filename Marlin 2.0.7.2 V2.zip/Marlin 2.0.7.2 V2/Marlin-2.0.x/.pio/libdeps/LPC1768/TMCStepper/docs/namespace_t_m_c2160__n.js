var namespace_t_m_c2160__n =
[
    [ "IOIN_t", "struct_t_m_c2160__n_1_1_i_o_i_n__t.html", "struct_t_m_c2160__n_1_1_i_o_i_n__t" ],
    [ "PWM_SCALE_t", "struct_t_m_c2160__n_1_1_p_w_m___s_c_a_l_e__t.html", "struct_t_m_c2160__n_1_1_p_w_m___s_c_a_l_e__t" ],
    [ "PWMCONF_t", "struct_t_m_c2160__n_1_1_p_w_m_c_o_n_f__t.html", "struct_t_m_c2160__n_1_1_p_w_m_c_o_n_f__t" ]
];