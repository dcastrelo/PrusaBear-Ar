var searchData=
[
  ['gconf_701',['GCONF',['../class_t_m_c2130_stepper.html#aee84a9abfc84b387c6ae5658f90bf684',1,'TMC2130Stepper::GCONF()'],['../class_t_m_c2130_stepper.html#ad7e2c224a86768c38c5167b2bee7de05',1,'TMC2130Stepper::GCONF(uint32_t value)'],['../class_t_m_c2208_stepper.html#a20d275e1dba5fe4ab75fc405b2f46281',1,'TMC2208Stepper::GCONF(uint32_t input)'],['../class_t_m_c2208_stepper.html#a549db4f962d4ae698dda33ef9a708e33',1,'TMC2208Stepper::GCONF()']]],
  ['global_5fscaler_702',['GLOBAL_SCALER',['../class_t_m_c2160_stepper.html#a182c03c51d92c565b15b6e7e459e55ae',1,'TMC2160Stepper::GLOBAL_SCALER(uint8_t)'],['../class_t_m_c2160_stepper.html#a4dc485fd467892f35f98ad6ea30b6d21',1,'TMC2160Stepper::GLOBAL_SCALER()']]],
  ['gstat_703',['GSTAT',['../class_t_m_c_stepper.html#af834b7aecb144c7d5c3ba1494eb447a8',1,'TMCStepper::GSTAT(uint8_t input)'],['../class_t_m_c_stepper.html#ac7874c4b56bd1b3acce522c1e7d7dfed',1,'TMCStepper::GSTAT()']]]
];
