var struct_f_a_c_t_o_r_y___c_o_n_f__t =
[
    [ "fclktrim", "struct_f_a_c_t_o_r_y___c_o_n_f__t.html#a896933528ea5123aafd78f63ae279e0d", null ],
    [ "ottrim", "struct_f_a_c_t_o_r_y___c_o_n_f__t.html#a4ccd32b132b5cffb896d86716629d7fa", null ],
    [ "sr", "struct_f_a_c_t_o_r_y___c_o_n_f__t.html#a8c0ab60d7c4c211ec0e37c13d9e0dd99", null ]
];