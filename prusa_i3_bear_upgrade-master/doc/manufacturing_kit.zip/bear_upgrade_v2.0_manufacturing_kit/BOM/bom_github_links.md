# Prusa i3 Bear Upgrade

## Hardware BOM

### Full Upgrade

* [For Prusa i3 MK2(s)](https://github.com/gregsaun/prusa_i3_bear_upgrade/blob/master/full_upgrade/for_mk2_mk2s/manual/bom.md)
* [For Prusa i3 MK2.5](https://github.com/gregsaun/prusa_i3_bear_upgrade/blob/master/full_upgrade/for_mk2.5/manual/bom.md)
* [For Prusa i3 MK3](https://github.com/gregsaun/prusa_i3_bear_upgrade/blob/master/full_upgrade/for_mk3/manual/bom.md)

### Half Upgrade

* [For Prusa i3 MK2(s) and MK2.5](https://github.com/gregsaun/prusa_i3_bear_upgrade/blob/master/half_upgrade/manual/bom.md)